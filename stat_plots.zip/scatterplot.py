#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 19:50:12 2018

@author: meghagoel
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np
#create dataframe
df=pd.read_csv(sys.argv[1], header=None, names=['year', 'population'])

#plot scatter with first column as x values and second column as y values
plt.scatter(df['year'],df['population'],color='#ddbbaa',label="Population")

#specifying labels
plt.xlabel("years")
plt.ylabel("population (as on 1st October each year)")
plt.title("Population trend with passing years in Haryana")
#enable legend
plt.legend()
plt.show()
