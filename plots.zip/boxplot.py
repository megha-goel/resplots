#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 19:49:50 2018

@author: meghagoel
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np
#create dataframe from csv
df=pd.read_csv(sys.argv[1], header=None, names=['INDEX','place', 'score1','score2','score3','score4','score5','score6','score7','score8','score9' ])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['score1'].dropna().tolist())
plotMap.append(df['score2'].dropna().tolist())
plotMap.append(df['score3'].dropna().tolist())
#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2,3],["BoxPlot-cycle1","BoxPlot-cycle2","BoxPlot-cycle3"])
plt.ylabel("Scores")
plt.title("Maths scores in various districts in three cycles")


plt.legend()
plt.show()