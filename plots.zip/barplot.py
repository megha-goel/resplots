#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 19:45:06 2018

@author: meghagoel
"""
import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np


#reading data frame from a csv file
df=pd.read_csv(sys.argv[1], header=None, names=['district','jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec','tot'])

num=len(df['jan'])
mat=np.empty(shape=[num])
for x in range(0,num): mat[x]=x+2

#plot bar plot with xticks which is position of bars as first argument and height of bars as second argument
plt.bar(mat,df['jan'],color='#ddbbaa',label="Rainfall in mm")

#specify labels on xticks
plt.xticks(mat,df['district'])
plt.xlabel("Districts")
plt.ylabel("Rainfall")
plt.title("Rainfall in the month of January")

#enabling legend
plt.legend()
plt.show()
